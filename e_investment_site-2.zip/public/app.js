const backdrop=document.getElementById('modalBackdrop');
const loginWrap=document.getElementById('loginFormWrap');
const registerWrap=document.getElementById('registerFormWrap');

function openModal(type){backdrop.classList.add('open');showForm(type);}
function closeModal(){backdrop.classList.remove('open');}
function showForm(type){
  const reg=type==='register';
  loginWrap.classList.toggle('hidden',reg);
  registerWrap.classList.toggle('hidden',!reg);
  document.querySelector('#'+(reg?'registerForm':'loginForm')+' input')?.focus();
}
document.querySelectorAll('[data-modal]').forEach(b=>b.addEventListener('click',()=>openModal(b.dataset.modal)));
document.querySelectorAll('[data-switch]').forEach(b=>b.addEventListener('click',()=>showForm(b.dataset.switch)));
document.getElementById('closeModal').addEventListener('click',closeModal);
backdrop.addEventListener('click',e=>{if(e.target===backdrop)closeModal();});

async function postJSON(url,data){
  const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
  const body=await r.json().catch(()=>({message:'Unexpected server response.'}));
  if(!r.ok) throw new Error(body.message||'Request failed.');
  return body;
}
document.getElementById('registerForm').addEventListener('submit',async e=>{
  e.preventDefault();
  const f=new FormData(e.target);
  const msg=document.getElementById('registerMessage');
  msg.textContent='Creating your account…';
  try{
    const result=await postJSON('/api/register',{
      name:f.get('name'),email:f.get('email'),phone:f.get('phone'),password:f.get('password')
    });
    msg.textContent=result.message;
    e.target.reset();
  }catch(err){msg.textContent=err.message;}
});
document.getElementById('loginForm').addEventListener('submit',async e=>{
  e.preventDefault();
  const f=new FormData(e.target);
  const msg=document.getElementById('loginMessage');
  msg.textContent='Signing in…';
  try{
    const result=await postJSON('/api/login',{email:f.get('email'),password:f.get('password')});
    msg.textContent=result.message;
    if(result.ok) setTimeout(closeModal,700);
  }catch(err){msg.textContent=err.message;}
});
